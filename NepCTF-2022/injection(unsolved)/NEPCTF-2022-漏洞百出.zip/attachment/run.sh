#!/bin/bash
#chmod 0 flag

ulimit -t 55 #max cpu using
ulimit -m 524288 #max memory
/bin/bash