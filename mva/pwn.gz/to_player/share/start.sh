#!/bin/bash
exec 2>/dev/null
/home/ctfer/mva
